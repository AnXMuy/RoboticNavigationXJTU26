#include <ebotController.h>
#include <PidControl.h>
#include <tf/transform_datatypes.h>
#include <iostream>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
namespace ebot_controller{

ebotControllerNode::ebotControllerNode(ros::NodeHandle &n){

    tf::TransformBroadcaster br;
    tf::TransformListener listener;
    tf_listener_ = new tf::TransformListener();
    //sub
    // sub_rear_pose = n.subscribe("/vehicle/rear_pose",1,&ebotControllerNode::pose_cb,this);

    sub_final_waypoints = n.subscribe("/base_waypoints",1,&ebotControllerNode::lane_cb,this);

    // sub_twist_cmd = n.subscribe("/vehicle/cmd",1,&ebotControllerNode::vel_cb,this);

    //test
    sub_pose = n.subscribe("/odom",1,&ebotControllerNode::pose_cb_test,this);
    //pub
    pub_twist_cmd = n.advertise<geometry_msgs::Twist>("/cmd_vel", 1);

    control_timer_ = n.createTimer(ros::Duration(0.02), &ebotControllerNode::ControlCallback,this);
}

double ebotControllerNode::getdistance(geometry_msgs::Point A,geometry_msgs::Point B)
{
    double d = sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y));
    return d;
}



void ebotControllerNode::vel_cb(const geometry_msgs::Twist msg)
{
    geometry_msgs::Twist velocity = msg;
}


//test
void ebotControllerNode::pose_cb_test(const nav_msgs::Odometry msg)
{

    my_odom.pose.pose.position.x = msg.pose.pose.position.x;
    my_odom.pose.pose.position.y = msg.pose.pose.position.y;
                //tf广播
    tf::TransformBroadcaster br;
    tf::Transform transform;
    transform.setOrigin( tf::Vector3(my_odom.pose.pose.position.x, my_odom.pose.pose.position.y, 0) );
    transform.setRotation( tf::Quaternion(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,msg.pose.pose.orientation.z,msg.pose.pose.orientation.w) );
    br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "/odom","/base_link"));
    std::cout<<"CurrentX:"<<my_odom.pose.pose.position.x<<"CurrentY:"<<my_odom.pose.pose.position.y<<std::endl;

}

void ebotControllerNode::lane_cb(const styx_msgs::Lane::ConstPtr &recieved_curve) //读取路径
{
    // std::cout<<"4444444444" << std::endl;
    final_waypoints.header.frame_id = recieved_curve->header.frame_id;
    final_waypoints.header.stamp = ros::Time::now();
    final_waypoints.poses.resize(recieved_curve->waypoints.size());
    for (size_t i = 0;i < recieved_curve->waypoints.size(); i++) {
        final_waypoints.poses[i].pose.position.x = recieved_curve->waypoints[i].pose.pose.position.x;
        final_waypoints.poses[i].pose.position.y = recieved_curve->waypoints[i].pose.pose.position.y;
    }
    // std::cout<< final_waypoints.poses[5].pose.position.x << std::endl;

    
}

void ebotControllerNode::nearest_point_index(const nav_msgs::Path &msg)  //求取目标参考点索引
{

    
    //test
    double currentX = my_odom.pose.pose.position.x;//当前车辆位置坐标
    double currentY = my_odom.pose.pose.position.y;
    geometry_msgs::Point current_pose_;
    current_pose_.x = currentX;
    current_pose_.y = currentY;

    //double r = r_distance*r_distance;
    int len = final_waypoints.poses.size(); //坐标点数量
    std::cout<< "len:" << len << std::endl;
    //std::cout<< final_waypoints.poses[0].pose.position.x << std::endl;
    target_point_index = 0;
    
    // double min_distance = 0.1;
    int i = 0;
    if (final_waypoints.poses.size()>0)
    {
        for (int num = i; num<len; num++) 
        {
            double min_distance = sqrt(pow((currentX - final_waypoints.poses[i].pose.position.x),2)+pow((currentY-final_waypoints.poses[i].pose.position.y),2));
            geometry_msgs::Point select_pose;
            select_pose.x = final_waypoints.poses[num].pose.position.x;
            select_pose.y = final_waypoints.poses[num].pose.position.y;
            double current_dis = getdistance(current_pose_,select_pose);//车辆位置和选取点距离
            // std::cout<< "××××××××××××current_pose_:" << current_pose_.x <<"," << current_pose_.y << std::endl;
            // std::cout<< "select_pose:" << select_pose.x << "," <<select_pose.y << std::endl;
            // std::cout<< "#############min_distance:" << min_distance << std::endl;
            // std::cout<< "current_dis:" << current_dis << std::endl;        
            if(current_dis <  min_distance)
            {
                min_distance = current_dis;

                target_point_index = num;
                i = num;
                if (target_point_index<45)
                {
                    target_point_index += 1;
                }
                
                

            }    

            // std::cout<< "target_point_index:" << final_waypoints.poses[target_point_index].pose.position.x << ","<< final_waypoints.poses[target_point_index].pose.position.y << std::endl;
        }
    }

}


// speed pid control
void ebotControllerNode::ControlCallback(const ros::TimerEvent& event){
    control_period_ = 0.02;
    max_steering_theta = 25;
    min_steering_theta = -25;
    PidControl P;
    // std::cout<< "22222222" << std::endl;
    double control_period = control_period_;
    double steering_theta = steering_theta_;
    P.set(0.4,0.3,0);
    nearest_point_index(final_waypoints);

    //目标参考点位置
    if (final_waypoints.poses.size()>0)
    {
        targetX = final_waypoints.poses[target_point_index].pose.position.x;
        targetY = final_waypoints.poses[target_point_index].pose.position.y;
    }

    // get_nearest_dis();
    // steering_theta = P.step(intercept,control_period);

    //监听
    tf::TransformListener listener;
    geometry_msgs::PointStamped base_link_point;
    base_link_point.header.frame_id = "/odom";
    base_link_point.header.stamp = ros::Time();
        
    //base_link_point检测点获取，即目标点对车辆坐标系的转换
    // std::cout<<"targetx:"<<targetX<<"targetY:"<<targetY<<std::endl;
    base_link_point.point.x = targetX;
    base_link_point.point.y = targetY;
    base_link_point.point.z = 0.0;
    geometry_msgs::PointStamped vehicle_frame_point;
    try{
        // 等待获取监听信息并获取转换坐标信息
        listener.waitForTransform("/base_link", "/odom", ros::Time(0), ros::Duration(3.0));
        listener.transformPoint("/base_link", base_link_point, vehicle_frame_point);
        intercept = fabs(vehicle_frame_point.point.y);
        ROS_INFO("odom: (%.2f, %.2f. %.2f) -----> base_link: (%.2f, %.2f, %.2f) at time %.2f",
            base_link_point.point.x, base_link_point.point.y, base_link_point.point.z,
            vehicle_frame_point.point.x, vehicle_frame_point.point.y, vehicle_frame_point.point.z, vehicle_frame_point.header.stamp.toSec());
        // std::cout<<"vehicle_frame_point.point.y:"<< vehicle_frame_point.point.y << std::endl;
        std::cout<<"intercept:"<<intercept<<std::endl;
        std::cout<<"vehicle_frame_point.point.y:"<<vehicle_frame_point.point.y<<std::endl;
    }
    catch(tf::TransformException& ex){
        ROS_ERROR("Received an exception trying to transform a point from \"base_laser\" to \"base_link\": %s", ex.what());
    }



    steering_theta = P.step(intercept);
    //判断车辆及轨迹的位置关系
    if (vehicle_frame_point.point.y > 0)
    {
        steering_theta = steering_theta;
    }
    else
    {
        steering_theta = -steering_theta;
    }
    
    std::cout<<"steering_theta:"<<steering_theta<<std::endl;

    velocity_ =  velocity.linear.x;
    std::cout<<"velocity_:"<<velocity_<<std::endl;

    geometry_msgs::Twist cmd_twist;
    //cmd_twist.linear.x = velocity_;
    cmd_twist.linear.x = 0.5;
    cmd_twist.angular.z = steering_theta;
    pub_twist_cmd.publish(cmd_twist);
}


}



















