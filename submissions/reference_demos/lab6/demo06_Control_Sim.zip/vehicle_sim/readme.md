run
    $ roslaunch vehicle_sim vehicle_sim.launch