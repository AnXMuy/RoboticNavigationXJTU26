#ifndef VEHICLE_SIM_H_
#define VEHICLE_SIM_H_

#include <math.h>

#include <ros/ros.h>
#include <ros/time.h>
#include <std_msgs/Int32.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Twist.h>
#include <tf/tf.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include "vehicle_sim.h"

#define WHEEL_BASE                    0.313     // meter

class VehicleSim
{
 public:
  VehicleSim();
  ~VehicleSim();
  bool init();
  bool update();

 private:
  // ROS NodeHandle
  ros::NodeHandle nh_;
  ros::NodeHandle nh_priv_;

  // ROS Time
  ros::Time last_cmd_vel_time_;
  ros::Time prev_update_time_;

  // ROS Topic Publishers
  ros::Publisher odom_pub_;

  // ROS Topic Subscribers
  ros::Subscriber cmd_vel_sub_;

  nav_msgs::Odometry odom_;
  tf::TransformBroadcaster tf_broadcaster_;

  double goal_linear_velocity_;
  double goal_steering_wheel_angle_;
  double cmd_vel_timeout_;

  float  odom_pose_[3];
  float  odom_vel_[3];

  // Function prototypes
  void commandVelocityCallback(const geometry_msgs::TwistConstPtr cmd_vel_msg);
  bool updateOdometry(ros::Duration diff_time);
  void updateTF(geometry_msgs::TransformStamped& odom_tf);
};

#endif // VEHICLE_SIM_H_
